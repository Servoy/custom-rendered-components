/**
 *  Adds a tab to this accordion with that form and text on the given index
 */
 function addTab (form, tabText, index) {}

/**
 *  Return the Tab of the given index
 */
 function getTabAt (index) {}

/**
 * Removes a tab of the given index
 * Return true if this was sucessfull
 */
function removeTabAt(index) {}

/**
 * Select the tab of the given index.
 * Return true if this was succesfull.
 */
function selectTabAt(index) {}

